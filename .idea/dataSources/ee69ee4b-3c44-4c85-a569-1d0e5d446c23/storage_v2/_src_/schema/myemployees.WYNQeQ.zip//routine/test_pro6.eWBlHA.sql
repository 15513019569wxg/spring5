create
    definer = root@`%` procedure test_pro6(IN startIndex int, IN size int)
begin
    select * from girls.beauty limit startIndex, size;
end;

